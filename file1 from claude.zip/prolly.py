# { "Depends": "py-genlayer:test" }
#
# NOTE ON THIS PRAGMA: kept as "py-genlayer:test" to match the existing
# genlayer-template-test setup. Production/testnet deploys typically pin an
# exact runtime hash instead, e.g.
#   { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
# Confirm the correct value for your target network before deploying anywhere
# other than local Direct Mode / Studio tests.
#
# NOTE ON API VERSION: this contract uses the *current* namespaced GenLayer
# API (gl.nondet.web.render, gl.eq_principle.strict_eq, gl.vm.UserError-style
# errors). Your genlayer-template-test/requirements.txt currently pins
# genlayer-test==0.1.1, which predates this namespacing (it used the old
# flat gl.get_webpage / gl.eq_principle_strict_eq calls). If your localnet
# is still on that old runtime, this contract will fail to import until you
# either bump genlayer-test to a current 0.2x/0.29.x release, or this gets
# rewritten against the old flat API. Worth confirming which one you're on
# before you try to deploy this.

from genlayer import *
import hashlib
import json


# drand's quicknet chain: fast (~3s), publicly verifiable randomness beacon.
# https://api.drand.sh/v2/chains/<hash>/info
DRAND_CHAIN_HASH = "52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971"
DRAND_ROUND_URL = f"https://api.drand.sh/v2/chains/{DRAND_CHAIN_HASH}/public/" + "{round}"

# How many drand rounds ahead of "now" to commit to. Must be far enough out
# that the round genuinely hasn't been published yet at commit time (so
# nobody, including the owner, can know the randomness in advance), but not
# so far that closing takes forever. With quicknet's ~3s period, 10 rounds
# is ~30s of real time.
REVEAL_ROUND_BUFFER = 10


class Prolly(gl.Contract):
    owner: str
    winner_count: u256

    participants: DynArray[str]
    joined: TreeMap[str, bool]

    is_closed: bool
    reveal_round: u256
    randomness: str
    winners: DynArray[str]

    def __init__(self, winner_count: int):
        if winner_count < 1:
            raise Exception("winner_count must be at least 1")

        self.owner = str(gl.message.sender_address)
        self.winner_count = winner_count

        self.participants = DynArray[str]()
        self.joined = TreeMap[str, bool]()

        self.is_closed = False
        self.reveal_round = 0
        self.randomness = ""
        self.winners = DynArray[str]()

    # ---------------------------------------------------------------
    # Joining
    # ---------------------------------------------------------------

    @gl.public.write
    def join(self, participant: str) -> None:
        if self.is_closed:
            raise Exception("Prolly is closed")

        if participant in self.joined:
            raise Exception("Participant already joined")

        self.joined[participant] = True
        self.participants.append(participant)

    @gl.public.view
    def has_joined(self, participant: str) -> bool:
        return self.joined.get(participant, False)

    @gl.public.view
    def get_participant_count(self) -> int:
        return len(self.participants)

    # ---------------------------------------------------------------
    # Closing: commit to a future, not-yet-published drand round
    # ---------------------------------------------------------------

    @gl.public.write
    def close_and_commit_reveal_round(self) -> int:
        """
        Owner-only. Locks joining and commits to a drand round that has not
        been published yet. Because the round is in the future relative to
        this transaction, the randomness used to pick winners cannot be
        known by anyone -- including the contract owner -- at commit time.
        """
        if str(gl.message.sender_address) != self.owner:
            raise Exception("Only the owner can close this Prolly")

        if self.is_closed:
            raise Exception("Already closed")

        if len(self.participants) == 0:
            raise Exception("No participants to draw from")

        def fetch_latest_round() -> str:
            body = gl.nondet.web.render(
                DRAND_ROUND_URL.format(round=0),  # round=0 -> drand returns latest
                mode="text",
            )
            data = json.loads(body)
            return json.dumps({"round": data["round"]}, sort_keys=True)

        # KNOWN LIMITATION: this reads drand's "latest" round live. Validators
        # evaluate this within the same consensus round, but if two
        # validators happen to poll right across a ~3s round boundary they
        # could disagree, and eq_principle.strict_eq would fail this
        # transaction (safe failure -- caller just retries). This is a real
        # tradeoff of using a live "latest" read instead of an on-chain
        # timestamp; flagging it rather than hiding it.
        latest_json = gl.eq_principle.strict_eq(fetch_latest_round)
        latest_round = json.loads(latest_json)["round"]

        target_round = int(latest_round) + REVEAL_ROUND_BUFFER

        self.is_closed = True
        self.reveal_round = target_round

        return target_round

    # ---------------------------------------------------------------
    # Revealing: fetch the now-published randomness and select winners
    # ---------------------------------------------------------------

    @gl.public.write
    def reveal_and_select_winners(self) -> list[str]:
        """
        Callable by anyone once the committed round has actually been
        published by drand (calling too early simply fails the fetch /
        consensus and can be retried). Derives winners with a seeded,
        deterministic partial Fisher-Yates shuffle so anyone can
        independently reproduce the exact same result from
        get_verification_material().
        """
        if not self.is_closed:
            raise Exception("Prolly has not been closed yet")

        if len(self.winners) > 0:
            raise Exception("Winners already selected")

        round_number = int(self.reveal_round)
        url = DRAND_ROUND_URL.format(round=round_number)

        def fetch_round_randomness() -> str:
            body = gl.nondet.web.render(url, mode="text")
            data = json.loads(body)

            if int(data["round"]) != round_number:
                raise Exception("Unexpected round returned by drand")

            # 'randomness' is the round's BLS-signature-derived output --
            # public, deterministic once published, and independently
            # verifiable against drand's own public keys off-chain.
            return data["randomness"]

        randomness_hex = gl.eq_principle.strict_eq(fetch_round_randomness)
        self.randomness = randomness_hex

        participants_copy = list(gl.storage.copy_to_memory(self.participants))
        n = len(participants_copy)
        k = min(int(self.winner_count), n)

        seed_material = (randomness_hex + ":" + str(round_number)).encode()
        seed = int.from_bytes(hashlib.sha256(seed_material).digest(), "big")

        pool = participants_copy
        for i in range(k):
            seed = int.from_bytes(
                hashlib.sha256(
                    seed.to_bytes(32, "big") + i.to_bytes(4, "big")
                ).digest(),
                "big",
            )
            j = i + (seed % (n - i))
            pool[i], pool[j] = pool[j], pool[i]

        selected = pool[:k]

        self.winners = DynArray[str]()
        for w in selected:
            self.winners.append(w)

        return selected

    # ---------------------------------------------------------------
    # Reading results / verification
    # ---------------------------------------------------------------

    @gl.public.view
    def get_winners(self) -> list[str]:
        return list(self.winners)

    @gl.public.view
    def get_verification_material(self) -> str:
        """
        Everything an outside party needs to independently re-run the same
        selection and confirm the winners without trusting this contract:
        the committed drand round, its published randomness, the full
        participant list, and the winner count. The same sha256-seeded
        Fisher-Yates used above, run over this data, must reproduce
        get_winners() exactly.
        """
        return json.dumps(
            {
                "reveal_round": int(self.reveal_round),
                "randomness": self.randomness,
                "participants": list(gl.storage.copy_to_memory(self.participants)),
                "winner_count": int(self.winner_count),
                "winners": list(self.winners),
            },
            sort_keys=True,
        )
