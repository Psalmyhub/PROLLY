from gltest import get_contract_factory
from gltest.assertions import tx_execution_succeeded


def deploy_contract(winner_count: int = 1):
    factory = get_contract_factory("Prolly")
    return factory.deploy(args=[winner_count])


def test_prolly_join_and_count():
    contract = deploy_contract(winner_count=1)

    count = contract.get_participant_count(args=[])
    assert count == 0

    result = contract.join(args=["alice"])
    assert tx_execution_succeeded(result)

    count = contract.get_participant_count(args=[])
    assert count == 1

    joined = contract.has_joined(args=["alice"])
    assert joined is True


def test_prolly_rejects_duplicate_join():
    contract = deploy_contract(winner_count=1)

    contract.join(args=["alice"])
    result = contract.join(args=["alice"])

    assert not tx_execution_succeeded(result)


def test_prolly_full_draw_flow():
    """
    Requires network access to api.drand.sh from the node(s) running this
    test (real Studio-mode / localnet deployment, not an offline sandbox).
    Exercises the full commit -> reveal -> verification-material flow.
    """
    contract = deploy_contract(winner_count=2)

    for name in ["alice", "bob", "carol", "dave"]:
        result = contract.join(args=[name])
        assert tx_execution_succeeded(result)

    assert contract.get_participant_count(args=[]) == 4

    close_result = contract.close_and_commit_reveal_round(args=[])
    assert tx_execution_succeeded(close_result)

    # NOTE: in a real run you likely need to wait (~REVEAL_ROUND_BUFFER *
    # drand period seconds) before the committed round is actually
    # published, otherwise reveal_and_select_winners() will fail the web
    # fetch / consensus check. This test does not sleep for you -- add a
    # wait or retry loop here once you're running it against a live node.
    reveal_result = contract.reveal_and_select_winners(args=[])
    assert tx_execution_succeeded(reveal_result)

    winners = contract.get_winners(args=[])
    assert len(winners) == 2
    assert len(set(winners)) == 2  # no duplicate winners

    material = contract.get_verification_material(args=[])
    assert material is not None
